package nv.cclm.standardservice.standardservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StandardserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StandardserviceApplication.class, args);
	}

}
