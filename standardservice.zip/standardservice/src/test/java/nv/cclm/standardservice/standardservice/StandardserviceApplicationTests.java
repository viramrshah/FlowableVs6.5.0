package nv.cclm.standardservice.standardservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StandardserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
